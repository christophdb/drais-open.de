---
title: Sam Wilson
email: samwilson@email.com
image: "/images/avatar.png"
description: this is meta description
social:
  - name: github
    icon: fa-brands fa-github
    link: https://github.com

  - name: twitter
    icon: fa-brands fa-twitter
    link: https://twitter.com

  - name: linkedin
    icon: fa-brands fa-linkedin
    link: https://linkedin.com
---

lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostr navigation et dolore magna aliqua.
